/*
 * A.Manjunath CS10B001
 * */

public interface Comparable {
	public int compareTo(IComplex x);
}
